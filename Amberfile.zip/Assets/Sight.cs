using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sight : MonoBehaviour
{
    
    public Enemy me;
    RaycastHit2D hitinfo;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == me.enemy)
        {
            hitinfo = Physics2D.Raycast(transform.position, collision.transform.position);
            if(hitinfo == collision)
            {
                me.target = collision.gameObject;
            }
            
        }
    }
}
