using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mazegen : MonoBehaviour
{
    public int roomsize;
    public GameObject[] rooms;
    public GameObject[] startrooms;
    public GameObject[] endrooms;
    public int roomnum;
    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i < roomnum; i++)
        {
            if(i != 0 && i != roomnum - 1)
            {
                Instantiate(rooms[Random.Range(0, rooms.Length)], new Vector2(transform.position.x, transform.position.y + roomsize), Quaternion.identity);
                transform.position = new Vector2(transform.position.x, transform.position.y + roomsize);
            }
            if(i == 0)
            {
                Instantiate(startrooms[Random.Range(0, startrooms.Length)], transform.position, Quaternion.identity);
            }
            if(i == roomnum - 1)
            {
                Instantiate(endrooms[Random.Range(0, endrooms.Length)], new Vector2(transform.position.x, transform.position.y + roomsize), Quaternion.identity);
                transform.position = new Vector2(transform.position.x, transform.position.y + roomsize);
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
