using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float speed;
    public float travelrange;
    public float strtraveltime;
    float traveltime;
    Vector3 nextpoint;
    [HideInInspector]
    public GameObject target;
    public Transform eyes;
    public float sensingdistance;
    public string enemy;
    public float strtagrotime;
    float agrotime;
    private void FixedUpdate()
    {
        Collider2D[] surroundings = Physics2D.OverlapCircleAll(transform.position, sensingdistance);
        for (int i = 0; i < surroundings.Length; i++)
        {
            if(surroundings[i].tag == enemy)
            {
                target = surroundings[i].gameObject;
            }
        }
        if(target == null)
        {
            agrotime = strtagrotime;
            traveltime -= Time.deltaTime;
            if(traveltime <= 0)
            {
                nextpoint = new Vector2(Random.Range(transform.position.x - travelrange, transform.position.x + travelrange), Random.Range(transform.position.y - travelrange, transform.position.y + travelrange));
                traveltime = strtraveltime;
            }
            if (Vector2.Distance(transform.position, nextpoint) < 0.5)
            {
                nextpoint = new Vector2(Random.Range(transform.position.x - travelrange, transform.position.x + travelrange), Random.Range(transform.position.y - travelrange, transform.position.y + travelrange));
            }
            transform.position = Vector2.MoveTowards(transform.position, nextpoint, speed);
            var dir = nextpoint - transform.position;
            var angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
            eyes.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
        }
        if(target != null)
        {
            agrotime -= Time.deltaTime;
            if(agrotime <= 0)
            {
                target = null;
            }
            transform.position = Vector2.MoveTowards(transform.position, target.transform.position, speed * 2);
            var dir = target.transform.position - transform.position;
            var angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
            eyes.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
        }
    }
}

