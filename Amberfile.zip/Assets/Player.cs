using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class Player : MonoBehaviour
{
    public float speed;
    Rigidbody2D rb;
    public float strttimeawake;
    float timeawake;
    public Player otherplayer;
    public Image mysplit;
    public float splitopacity;
    public bool finish;
    public int nextlevel;
    Vector2 checkpoint;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        timeawake = strttimeawake;
        checkpoint = transform.position;
    }

    private void FixedUpdate()
    {
        Vector2 moveinput;
        moveinput.x = Input.GetAxisRaw("Horizontal");
        moveinput.y = Input.GetAxisRaw("Vertical");

        rb.velocity = moveinput * speed;
        timeawake -= Time.deltaTime;
        if(timeawake <= 0)
        {
            change();
        }
        if (Input.GetKey(KeyCode.E))
        {
            rb.velocity = new Vector2(speed, rb.velocity.y);
        }
        if(finish == true && otherplayer.finish == true)
        {
            SceneManager.LoadScene(nextlevel);
        }
    }

    void change()
    {
        if(otherplayer.finish == false)
        {
            otherplayer.enabled = true;
            rb.velocity = Vector2.zero;
            GetComponent<Player>().enabled = false;
            timeawake = strttimeawake;
            mysplit.color = new Color(mysplit.color.r, mysplit.color.g, mysplit.color.b, splitopacity);
            otherplayer.mysplit.color = new Color(mysplit.color.r, mysplit.color.g, mysplit.color.b, 0);
        }
        
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.collider.tag == "Enemy")
        {
            transform.position = checkpoint;
            GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");
            for (int i = 0; i < enemies.Length; i++)
            {
                enemies[i].GetComponent<Enemy>().target = null;
            }
            change();
        }
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Finish")
        {
            finish = true;
        }
    }
}
