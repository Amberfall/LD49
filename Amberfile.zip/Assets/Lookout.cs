using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lookout : MonoBehaviour
{
    public float rotationspeed;
    RaycastHit2D hitinfo;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    private void FixedUpdate()
    {
        transform.Rotate(0, 0, rotationspeed * Time.deltaTime);
        hitinfo = Physics2D.Raycast(transform.position, transform.right);
        if(hitinfo.collider.tag == "dreamplayer")
        {
            Collider2D[] team = Physics2D.OverlapCircleAll(transform.position, 100f);
            for (int i = 0; i < team.Length; i++)
            {
                if(team[i].GetComponent<Enemy>() != null)
                {
                    team[i].GetComponent<Enemy>().target = hitinfo.collider.gameObject;

                }
            }
        }
    }
}
